
// server.js
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Sample products
let products = [
  { id: 1, name: "Smartwatch", price: 99.99 },
  { id: 2, name: "Wireless Earbuds", price: 59.99 },
  { id: 3, name: "Bluetooth Speaker", price: 79.99 },
  { id: 4, name: "Portable Charger", price: 29.99 }
];

// In-memory cart
let cart = [];

// Get all products
app.get('/products', (req, res) => {
  res.json(products);
});

// Get current cart
app.get('/cart', (req, res) => {
  res.json(cart);
});

// Add item to cart
app.post('/cart', (req, res) => {
  const { productId } = req.body;
  const product = products.find(p => p.id === productId);
  if (product) {
    cart.push(product);
    res.status(201).json({ message: "Added to cart", cart });
  } else {
    res.status(404).json({ message: "Product not found" });
  }
});

// Clear cart
app.delete('/cart', (req, res) => {
  cart = [];
  res.json({ message: "Cart cleared" });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
